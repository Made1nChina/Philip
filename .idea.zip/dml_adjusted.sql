insert into blog (title, short_text, long_text, autor) values ('News 1', 'Irgend eine Nachricht', 'Irgend ein langer langer text', 'Enrico');
insert into blog (title, short_text, long_text, autor) values ('News 2', 'Irgend eine weitere Nachricht', 'Irgend ein weiterer langer langer text', 'Enrico');
insert into blog (title, short_text, long_text, autor) values ('News 3', 'Irgend eine weitere spannende Nachricht', 'Irgend ein weiterer langer langer spannender text', 'Enrico');
